# بناء APK من الموبايل فقط

1. أنشئ حسابًا على GitHub وسجّل الدخول.
2. أنشئ Repository جديدًا، مثل: AlMaystro.
3. فك ضغط هذا المشروع وارفع الملفات والمجلدات الموجودة داخله إلى المستودع.
4. افتح تبويب Actions.
5. اختر Build Android APK ثم Run workflow.
6. بعد نجاح البناء، افتح نتيجة التشغيل (workflow run).
7. من Artifacts حمّل AlMaystro-APK ثم فك الضغط لتحصل على app-debug.apk.

إعدادات التطبيق:
- Minimum SDK: API 28 (Android 9)
- Target SDK: API 36 (Android 16)
- Compile SDK: 36

ملاحظة: التطبيق WebView ويحتاج اتصال إنترنت لفتح رابط Whacka.
