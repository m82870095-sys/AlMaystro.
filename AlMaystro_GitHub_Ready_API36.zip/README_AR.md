# مشروع APK لتطبيق المايسترو

هذا المشروع يحوّل رابط Whacka إلى تطبيق Android بسيط باستخدام WebView.

الرابط:
https://almaystro-79k5.whacka.app

## ملاحظات
- التطبيق يحتاج إلى الإنترنت لأن المحتوى الأساسي موجود على Whacka.
- لا يحتوي المشروع على كود Whacka الأصلي؛ هو غلاف Android يفتح تطبيق الويب.
- تم ضبط JavaScript وDOM Storage لتوافق أفضل مع تطبيقات الويب الحديثة.

## إخراج APK مجانًا
1. افتح المشروع في Android Studio.
2. انتظر اكتمال Gradle Sync.
3. من القائمة اختر Build > Build APK(s).
4. ستجد ملف APK داخل:
   app/build/outputs/apk/debug/

لعمل نسخة Release موقعة للنشر، استخدم Build > Generate Signed Bundle / APK.
